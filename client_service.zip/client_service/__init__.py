"""
SessionSentry Client Service
A Windows event monitoring service that sends security events to a central server.
"""

__version__ = "1.0.0" 